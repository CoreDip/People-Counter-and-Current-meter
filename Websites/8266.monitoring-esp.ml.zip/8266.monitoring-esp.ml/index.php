<html>
<head>
  <title>Esp8266 Моніторинг електромережі</title>
  <meta http-equiv="Refresh" content="20" />
  <?php
  require 'Wh.php';
  require 'statistic.php';
  function admin(){
    $mysqli = new mysqli('localhost', 'root', 'root', '8266');
    echo "<script>self.location='admin.php';</script>";
  }
  if(array_key_exists('delete',$_POST)){
    admin();
  }
  ?>
  <style>
  .statisticwh{
    padding: 1%;
    background-color: #80FD7A;
    margin-left: -0.4%;
    margin-right: -0.4%;
  }
  .stats{
    font-size: 12pt;
    color: #2652C1;
    font-family: FreeMono, monospace;
    font-weight: bold;

  }
  .header{
    color: #3CE559;
    font-family: FreeMono, monospace;
    font-weight: bold;
    color: white;
    font-size: 18pt;
    text-align: center;
    margin: 1%;
    text-shadow: #43FE24 0 0 5px;
  }
  .delete{
      color: white;
      background-color: #C03642;
      border: 2px solid #F6300E;
      border-radius: 5px;
      box-shadow: #F6300E 0 0 8px;
      font-size: 14pt;
      padding: 0.5%;
      margin: 0.5%;
    }

    .c8266{
      color: white;
      background-color: #3CE559;
      border: 2px solid #17FF00;
      border-radius: 5px;
      box-shadow: #58FF00 0 0 8px;
      font-size: 14pt;
      padding: 0.5%;
      margin: 0.5%;
    }
    .c8266:hover {
      color: #0F9002; /* Цвет ссылки при наведении на нее курсора мыши */
      text-decoration: underline; /* Добавляем подчеркивание */
     }

     .delete:hover {
       color: #FF0000; /* Цвет ссылки при наведении на нее курсора мыши */
       text-decoration: underline; /* Добавляем подчеркивание */
      }

     .buttons{
       font-size: 12pt;
       color: #2652C1;
       font-family: FreeMono, monospace;
       font-weight: bold;
       display: inline;
     }

  </style>
</head>
<body bgcolor="#2a2a2b">
 <div class='header'>Веб сторінка моніторингу стану електромережі</div>
<div class='statisticwh'>
  <div class='stats'>Всього спожито:  <?php echo $Wh;?> Вт. </div>
  <div class='stats'>Остання відправка:   <?php echo $day.".".$month.".".$year." ".$time;?></div>
  <div class='stats'>Останнє значення струму:   <?php echo $current;?> А.</div>
    <div class='stats'>Остання потужність:   <?php echo $active;?> Вт\год.</div>
</div><br><br>

<?php require 'monitor.php'; ?><br>

<form method="post">
    <center>
      <div class='buttons'><a class='c8266' href="http://monitoring-esp.ml/" class="button">Назад</a></div>
      <div class='buttons'><a class='delete' href="http://8266.monitoring-esp.ml/admin.php">Аміністрування</a></div>
    </center>
</form>

  <div style="text-align: center;" class='statisticwh'>
Copyright© by Dipcore 2021
  </div>

</body>
</html>
