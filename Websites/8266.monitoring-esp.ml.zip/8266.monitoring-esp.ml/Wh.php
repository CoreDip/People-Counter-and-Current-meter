<?php
$mysqli = new mysqli('localhost', 'root', 'root', '8266');
$result = $mysqli->query('SELECT * FROM `wh`');
while(($row = $result->fetch_assoc()) !== null){
  $Wh=$row['Wh'];
}
?>
