<html>
<head>
  <title>Esp Моніторинг</title>
  <style>
  .statisticwh{
    padding: 1%;
    background: linear-gradient(to right, #3CE559, #FD621B);
    width: 101%;
    margin-left: -1%;
  }
  .stats{
    font-size: 12pt;
    color: #2652C1;
    font-family: FreeMono, monospace;
    font-weight: bold;
    display: inline;

  }
  .header{
    color: #3CE559;
    font-family: FreeMono, monospace;
    font-weight: bold;
    color: white;
    font-size: 18pt;
    text-align: center;
    margin: 1%;
    text-shadow: #43FE24 0 0 5px;
  }
  .c8266{
    color: white;
    background-color: #3CE559;
    border: 2px solid #17FF00;
    border-radius: 5px;
    box-shadow: #17FF00 0 0 8px;
    font-size: 34pt;
    width: 40%;
    margin: 4%;
    padding: 5%;
  }
  .c8266:hover {
    color: #0F9002; /* Цвет ссылки при наведении на нее курсора мыши */
    text-decoration: underline; /* Добавляем подчеркивание */
   }

  .c32{
    color: white;
    background-color: #FF8C57;
    border: 2px solid #F6300E;
    border-radius: 5px;
    box-shadow: #F6300E 0 0 8px;
    font-size: 34pt;
    width: 40%;
    padding: 5%;
    margin: 4%;
  }

  .c32:hover {
    color: #800000; /* Цвет ссылки при наведении на нее курсора мыши */
    text-decoration: underline; /* Добавляем подчеркивание */
   }



  </style>
</head>
<body bgcolor="#2a2a2b">
 <div class='header'>Оберіть, яка статистика вас цікавить:</div>
<div class='statisticwh'>
  <div class='stats'><button class='c8266' onclick="window.location.href = 'http://8266.monitoring-esp.ml/';">Статистика електромережі</button></div>
  <div class='stats'><button class='c32' onclick="window.location.href = 'http://32.monitoring-esp.ml/';">Статистика відвідувачів</button></div>
</div><br><br>

  <div style="text-align: center;" class='statisticwh'>
Copyright© by Dipcore 2021
  </div>

</body>
</html>
