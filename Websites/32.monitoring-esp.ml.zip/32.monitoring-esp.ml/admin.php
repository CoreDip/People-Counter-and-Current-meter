<?php
$valid_passwords = array ("admin" => "admin");
$valid_users = array_keys($valid_passwords);

$user = $_SERVER['PHP_AUTH_USER'];
$pass = $_SERVER['PHP_AUTH_PW'];

$validated = (in_array($user, $valid_users)) && ($pass == $valid_passwords[$user]);

if (!$validated) {
  header('WWW-Authenticate: Basic realm="My Realm"');
  header('HTTP/1.0 401 Unauthorized');
  die ("Не авторизовано!");
}
?>


<html>
<head>
  <title>Esp32 Адміністрування</title>
  <?php
  require 'peoplecounter.php';
  function delete(){
    $mysqli = new mysqli('localhost', 'root', 'root', '32');
    echo "<script>alert('Всі данні очищено!'); self.location='admin.php';</script>";
    $mysqli->query('DROP TABLE IF EXISTS peoplecounter;');
    $mysqli->query("CREATE TABLE IF NOT EXISTS peoplecounter (`record` INT(20) NOT NULL AUTO_INCREMENT, `datetime` VARCHAR(30), `people` INT(2), PRIMARY KEY(`record`));");
    $mysqli->query("INSERT INTO peoplecounter VALUES (NULL,'".date('Y-m-d H:i:s')."', 0);");
  }
  if(array_key_exists('delete',$_POST)){
    delete();
  }
  ?>
  <style>
  .statisticwh{
    padding: 1%;
    background-color: #FF8C57;
    width: 101%;
    margin-left: -1%;
  }
  .stats{
    font-size: 12pt;
    color: #2652C1;
    font-family: FreeMono, monospace;
    font-weight: bold;

  }
  .buttons{
    font-size: 12pt;
    color: #2652C1;
    font-family: FreeMono, monospace;
    font-weight: bold;
    display: inline;
  }
  .header{
    color: #3CE559;
    font-family: FreeMono, monospace;
    font-weight: bold;
    color: white;
    font-size: 18pt;
    text-align: center;
    margin: 1%;
    text-shadow: #FF0000 0 0 5px;
  }
  .delete{
      color: white;
      background-color: #C03642;
      border: 2px solid #F6300E;
      border-radius: 5px;
      box-shadow: #F6300E 0 0 8px;
      font-size: 14pt;
      padding: 0.5%;
      margin: 0.5%;
    }

    .delete:hover {
      color: #FF0000; /* Цвет ссылки при наведении на нее курсора мыши */
      text-decoration: underline; /* Добавляем подчеркивание */
     }

    .c32{
      color: white;
      background-color: #FF8C57;
      border: 2px solid #F6300E;
      border-radius: 5px;
      box-shadow: #F6300E 0 0 8px;
      font-size: 14pt;
      padding: 0.5%;
      margin: 0.5%;
    }

    .c32:hover {
      color: #800000; /* Цвет ссылки при наведении на нее курсора мыши */
      text-decoration: underline; /* Добавляем подчеркивание */
     }

  </style>
</head>
<body bgcolor="#2a2a2b">
 <div class='header'>Адміністрування</div>
 <div class='statisticwh'>
   <div class='stats'>Людей вдома:  <?php echo $people;?> чол </div>
   <div class='stats'>Остання відправка:   <?php echo $day.".".$month.".".$year." ".$time;?></div>
 </div><br><br>

  <form method="post">
      <center>
        <div class='buttons'><a class='c32' href="http://32.monitoring-esp.ml/" class="button">Назад</a></div>
        <div class='buttons'><input align='center' type="submit" name="delete" class="delete" value="Очистити статистику" /></div>
      </center>
  </form>

  </div>
  <div style="text-align: center;" class='statisticwh'>
Copyright© by Dipcore 2021
  </div>

</body>
</html>
</html>
