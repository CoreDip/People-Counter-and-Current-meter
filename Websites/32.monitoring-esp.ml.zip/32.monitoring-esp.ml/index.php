<html>
<head>
  <title>Esp32 Моніторинг відвідувачів</title>
  <meta http-equiv="Refresh" content="20" />
  <?php
  require 'peoplecounter.php';
  function admin(){
    echo "<script> self.location='admin.php';</script>";
  }
  if(array_key_exists('delete',$_POST)){
    admin();
  }
  ?>
  <style>
  .statisticwh{
    padding: 1%;
    background-color: #FF8C57;
    margin-left: -0.4%;
    margin-right: -0.4%;
  }
  .stats{
    font-size: 12pt;
    color: #2652C1;
    font-family: FreeMono, monospace;
    font-weight: bold;

  }
  .buttons{
    font-size: 12pt;
    color: #2652C1;
    font-family: FreeMono, monospace;
    font-weight: bold;
    display: inline;
  }
  .header{
    color: #3CE559;
    font-family: FreeMono, monospace;
    font-weight: bold;
    color: white;
    font-size: 18pt;
    text-align: center;
    margin: 1%;
    text-shadow: #FF0000 0 0 5px;
  }
  .delete{
      color: white;
      background-color: #C03642;
      border: 2px solid #F6300E;
      border-radius: 5px;
      box-shadow: #F6300E 0 0 8px;
      font-size: 14pt;
      padding: 0.5%;
      margin: 0.5%;
    }

    .delete:hover {
      color: #FF0000; /* Цвет ссылки при наведении на нее курсора мыши */
      text-decoration: underline; /* Добавляем подчеркивание */
     }

    .c32{
      color: white;
      background-color: #FF8C57;
      border: 2px solid #F6300E;
      border-radius: 5px;
      box-shadow: #F6300E 0 0 8px;
      font-size: 14pt;
      padding: 0.5%;
      margin: 0.5%;
    }

    .c32:hover {
      color: #800000; /* Цвет ссылки при наведении на нее курсора мыши */
      text-decoration: underline; /* Добавляем подчеркивание */
     }

  </style>
</head>
<body bgcolor="#2a2a2b">
 <div class='header'>Веб сторінка моніторингу людей в приміщенні</div>
<div class='statisticwh'>
  <div class='stats'>Людей вдома:  <?php echo $people;?> чол </div>
  <div class='stats'>Остання відправка:   <?php echo $day.".".$month.".".$year." ".$time;?></div>
</div><br><br>

<?php require 'monitor.php'; ?><br>

  <form method="post">
      <center>
        <div class='buttons'><a class='c32' href="http://monitoring-esp.ml/" class="button">Назад</a></div>
        <div class='buttons'><a class='delete' href="http://32.monitoring-esp.ml/admin.php">Аміністрування</a></div>
      </center>
  </form>
  <br>

  </div>
  <div style="text-align: center;" class='statisticwh'>
Copyright© by Dipcore 2021
  </div>

</body>
</html>
