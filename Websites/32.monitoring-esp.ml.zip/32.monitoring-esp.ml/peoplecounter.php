<?php
$mysqli = new mysqli('localhost', 'root', 'root', '32');
$result = $mysqli->query('SELECT people, datetime FROM peoplecounter WHERE record=(SELECT max(record) FROM peoplecounter);');

while(($row = $result->fetch_assoc()) !== null){
  $datetime=$row['datetime'];
  $people=$row['people'];
}

$year=$datetime[0].$datetime[1].$datetime[2].$datetime[3];
$month=$datetime[5].$datetime[6];
$day=$datetime[8].$datetime[9];
$time=$datetime[11].$datetime[12].$datetime[13].$datetime[14].$datetime[15].$datetime[16].$datetime[17].$datetime[18];
?>
