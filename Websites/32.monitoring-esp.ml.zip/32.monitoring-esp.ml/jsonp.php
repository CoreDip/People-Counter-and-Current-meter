<?php
date_default_timezone_set( 'UTC' );
$mysqli = new mysqli('localhost', 'root', 'root', '32');

$query = "SELECT `datetime`, `people` FROM `peoplecounter`;";
$result = $mysqli->query($query);

while ($record = $result->fetch_row()){
	$all[] =  array(strtotime($record[0]), (int)$record[1]);
}
echo json_encode($all);

$mysqli->close();
?>
